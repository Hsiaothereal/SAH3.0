<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>南區展覽</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/modern-business.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Roboto', 'Noto Sans TC', 'Microsoft JhengHei', 'PMingLiU', 'Lato', sans-serif;
    }

    .img-fluid {
      width: 100%;
      max-height: 330px;
      max-width: 700px;
      height: 100%;
    }
  </style>
</head>

<body>

  <!-- Navigation -->
  <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="index.php">展給你看</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              地區展覽
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
              <a class="dropdown-item" href="North-col.php">北區</a>
              <a class="dropdown-item" href="middle-col.php">中區</a>
              <a class="dropdown-item" href="south-col.php">南區</a>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              會員資訊
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
              <a class="dropdown-item" href="full-width.php">收藏的展覽</a>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Logout.php">登出</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- Page Content -->
  <div class="container">

    <!-- Page Heading/Breadcrumbs -->
    <h1 class="mt-4 mb-3">南區展覽</h1>

    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="index.html">首頁</a>
      </li>
      <li class="breadcrumb-item active">南區展覽</li>
    </ol>

    <!-- Project One -->
    <div class="row">
      <div class="col-md-7">
        <a href="info_02.html">
          <img class="img-fluid rounded mb-3 mb-md-0"
            src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/079/504/e7qgudhfu9lwxkbrsydtp5x9ux2io386_800x420^.jpg" alt="">
        </a>
      </div>
      <div class="col-md-5">
         <h3>犬世界景觀 張如安 個展</h3>
        <p>「在樂園系列的圖像中，犬化身為消費世界中，扁平的消費符號『#寵物』，寵物的身份從過去貴族的生活中被解放，大眾化、普遍化、娛樂化，當中不少基因改良的配種、純種犬在畫面中執行人們賦予他們的工作。」---張如安 創作的呈現是藝術家對於環境與日常所見的反應與思辯，#張如安 的童年和四隻小狗共同成長，與家犬爭風吃醋，對絨毛狗玩具訴說心事，同時也面對成長過程中必經的離散，對於「狗」又愛又恨，但也透過觀察犬逐漸了解這個社會與世界。</p>
        <a class="btn btn-primary" href="info_02.html">閱讀更多
          <span class="glyphicon glyphicon-chevron-right"></span>
        </a>
      </div>
    </div>
    <!-- /.row -->

    <hr>

    <!-- Project Two -->
    <div class="row">
      <div class="col-md-7">
        <a href="info_08.html">
          <img class="img-fluid rounded mb-3 mb-md-0"
            src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/413/obsh3ik5qjsv0i1exktn6yzdedobg8z4_1400x800.jpg"
            alt="">
        </a>
      </div>
      <div class="col-md-5">
        <h3>通關密語—華建强個展</h3>
        <p>生活中會面臨許多的選擇，而每個決定都會開啟不同的旅程。選擇就像是開啟未知道路的通關密語，等待開啟，等待改變。</p>
        <a class="btn btn-primary" href="info_08.html">閱讀更多
          <span class="glyphicon glyphicon-chevron-right"></span>
        </a>
      </div>
    </div>
    <!-- /.row -->

    <hr>

    <!-- Project Three -->
    <div class="row">
      <div class="col-md-7">
        <a href="info_09.html">
          <img class="img-fluid rounded mb-3 mb-md-0"
            src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/409/sg4vv2tiwkfj0j6cudn3h525ar15xao6_1400x800.jpg"
            alt="">
        </a>
      </div>
      <div class="col-md-5">
        <h3>隆隆隆!!!---很可以_培力研發所_I</h3>
        <p>
        由國立臺南生活美學館主辦〈隆隆隆!!!---很可以_培力研發所_I〉展覽經過2週的培力創作，即日起正式展出。走進國立臺南生活美學館大廳發現與過往的美學館有很大的不同，有個「很可以」的巨大標誌，寫著「青年創作培力計畫」，以及〈隆隆隆!!!---很可以_培力研發所_I〉的標題。</p>
        <a class="btn btn-primary" href="info_09.html">閱讀更多
          <span class="glyphicon glyphicon-chevron-right"></span>
        </a>
      </div>
    </div>
    <!-- /.row -->

    <hr>

    
    <!-- Pagination -->
   

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; SA project</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>