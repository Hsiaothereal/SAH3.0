<?php
session_start();
if (!isset($_SESSION["userID"])) {

  if (isset($_POST["username"]) && isset($_POST["password"])) {
    $username3 = $_POST["username"];
    $password3 = $_POST["password"];



    $hostname = "localhost";
    $username1 = "root";
    $password = "hsiao19999";
    $db_name = "exhibitionx";

    try {
      $db = new PDO(
        "mysql:host=" . $hostname . ";
                          dbname=" . $db_name,
        $username1,
        $password,
        array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")
      );
      //PDO::MYSQL_ATTR_INIT_COMMAND 設定編碼

      //echo '連線成功';
      $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //錯誤訊息提醒

      //Query SQL
      $sql = "SELECT user_ID, user_code from user;";
      $result = $db->query($sql);

      $datalist = $result->fetchAll();
      foreach ($datalist as $usernamelist) {
        if ($username3 == $usernamelist["user_ID"]) {
          $_SESSION["userID"] = $usename3;
          $_SESSION["userpassword"] = $password3;
          header("Location: index.php");
        } else {
          echo "<script> alert('Login failed');parent.location.href='Login.php'; </script>";
          header("Location: Login.php");
        }
      }
    } catch (PDOException $e) {
      echo $sql . "<br>" . $e->getMessage();
    }
  }
} else {
  header("Location: index.php");
}
?>



<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>展給你看-首頁</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/modern-business.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">


</head>

<body>

  <!-- Navigation -->
  <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="index.php">展給你看</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              地區展覽
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
              <a class="dropdown-item" href="North-col.php">北區</a>
              <a class="dropdown-item" href="middle-col.php">中區</a>
              <a class="dropdown-item" href="south-col.php">南區</a>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              會員資訊
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
              <a class="dropdown-item" href="full-width.php">收藏的展覽</a>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Logout.php">登出</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <header>
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner" role="listbox">
        <!-- Slide One - Set the background image for this slide in the line below -->
        <div class="carousel-item active" style="background-image: url(https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/295/wjuhyi5n7nn9ub1jjrvpnpki93cz1x2v_1400x800.jpg)">
          <div class="carousel-caption d-none d-md-block">
          </div>
        </div>
        <!-- Slide Two - Set the background image for this slide in the line below -->
        <div class="carousel-item" style="background-image: url(https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/333/evzz93lelan3iqdtf7ro169uwm1dt3hc_1400x800.jpg)">
          <div class="carousel-caption d-none d-md-block">
          </div>
        </div>
        <!-- Slide Three - Set the background image for this slide in the line below -->
        <div class="carousel-item" style="background-image: url(https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/390/qew7uk5srx3d2lu9tv87l9n63wdplxqt_1400x800.jpg)">
          <div class="carousel-caption d-none d-md-block">
          </div>
        </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
  </header>

  <!-- Page Content -->
  <div class="container" style="margin-top: 20px;">


    <!-- Portfolio Section -->
    <h2>熱門展覽</h2>

    <div class="row">
      <div class="col-lg-4 col-sm-6 portfolio-item">
        <div class="card h-100">
          <a href="info_02.html">
            <img class="card-img-top" src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/079/504/e7qgudhfu9lwxkbrsydtp5x9ux2io386_800x420^.jpg" alt="">
          </a>
          <div class="card-body">
            <h4 class="card-title">
              <a href="info_02.html">犬世界景觀 張如安 個展</a>
            </h4>
            <p class="card-text">
              <b>展期</b><br>
              日期：2020-05-02 ~ 2020-06-13<br>
              <br>
              <b>地點</b><br>
              704 臺南市北區民德路90巷50號</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-sm-6 portfolio-item">
        <div class="card h-100">
          <a href="info_03.html">
            <img class="card-img-top" src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/079/507/qj25pcpmmotomhrp1h25xqghl1cnjt4i_1400x800.jpg" alt="">
          </a>
          <div class="card-body">
            <h4 class="card-title">
              <a href="info_03.html">X計畫—交換日記</a>
            </h4>
            <p class="card-text">
              <b>展期</b><br>
              日期：2020-05-04 ~ 2020-06-05<br>
              <br>
              <b>地點</b><br>
              台北市內湖區堤頂大道二段99號</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-sm-6 portfolio-item">
        <div class="card h-100">
          <a href="info_04.html">
            <img class="card-img-top" src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/079/360/wkm7pkaw55oi89k1ldq6020522zxfhgh_1400x800.jpg" alt="">
          </a>
          <div class="card-body">
            <h4 class="card-title">
              <a href="info_04.html">深邃之城</a>
            </h4>
            <p class="card-text">
              <b>展期</b><br>
              日期：2020-04-18 ~ 2020-07-12<br>
              <br>
              <b>地點</b><br>
              台北市北投區大業路166號11樓</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-sm-6 portfolio-item">
        <div class="card h-100">
          <a href="info_05.html">
            <img class="card-img-top" src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/079/478/6uul39pv2y60ccyt44hpayhti9kzzh1n_1400x800.jpg" alt="">
          </a>
          <div class="card-body">
            <h4 class="card-title">
              <a href="info_05.html">林忠良創作展</a>
            </h4>
            <p class="card-text">
              <b>展期</b><br>
              日期：2020-07-06 ~ 2020-07-31<br>
              <br>
              <b>地點</b><br>
              市民大道七段7號</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-sm-6 portfolio-item">
        <div class="card h-100">
          <a href="info_01.html" target="_blanket">
            <img class="card-img-top" src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/079/452/4xo2hd71lzh59vqbboggjbu8f60wlbdn_1400x800.jpg" alt="">
          </a>
          <div class="card-body">
            <h4 class="card-title">
              <a href="info_01.html">阿麗莎·柯維德首度台灣個展</a>
            </h4>
            <p class="card-text">
              <b>展期</b><br>
              日期：2020-04-28 ~ 2020-07-19<br>
              <br>
              <b>地點</b><br>
              內湖區寶湖里13鄰民權東路六段180巷10弄6號1樓</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-sm-6 portfolio-item">
        <div class="card h-100">
          <a href="info_06.html">
            <img class="card-img-top" src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/448/8e3qn6mb334hbnfvwi20o9k3a798ewnm_1400x800.jpg" alt="">
          </a>
          <div class="card-body">
            <h4 class="card-title">
              <a href="info_06.html">The Antinferno 安蒂菲諾</a>
            </h4>
            <p class="card-text"><b>展期</b><br>
              日期：2020-06-13 ~ 2020-07-12<br>
              <br>
              <b>地點</b><br>
              台北市大同區民族西路141號</p>
          </div>
        </div>
      </div>
    </div>

    <hr>
    <h2>推薦展覽</h2>

    <div class="row">
      <div class="col-lg-4 col-sm-6 portfolio-item">
        <div class="card h-100">
          <a href="info_07.html">
            <img class="card-img-top" src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/414/b7fnlnxrhw66dupp47b0oezilm6z8jm3_1400x800.jpg" alt="">
          </a>
          <div class="card-body">
            <h4 class="card-title">
              <a href="info_07.html">凹凸世界 版畫聯展</a>
            </h4>
            <p class="card-text">
              <b>展期</b><br>
              日期：2020-06-01 ~ 2020-06-30<br>
              <br>
              <b>地點</b><br>
              台中市西區林森路38巷1號</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-sm-6 portfolio-item">
        <div class="card h-100">
          <a href="info_08.html">
            <img class="card-img-top" src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/413/obsh3ik5qjsv0i1exktn6yzdedobg8z4_1400x800.jpg" alt="">
          </a>
          <div class="card-body">
            <h4 class="card-title">
              <a href="info_08.html">通關密語—華建强個展</a>
            </h4>
            <p class="card-text">
              <b>展期</b><br>
              日期：2020-05-22 ~ 2020-06-21<br>
              <br>
              <b>地點</b><br>
              臺南市中西區南門路37號</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-sm-6 portfolio-item">
        <div class="card h-100">
          <a href="info_09.html">
            <img class="card-img-top" src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/409/sg4vv2tiwkfj0j6cudn3h525ar15xao6_1400x800.jpg" alt="">
          </a>
          <div class="card-body">
            <h4 class="card-title">
              <a href="info_09.html">隆隆隆!!!---很可以_培力研發所_I</a>
            </h4>
            <p class="card-text">
              <b>展期</b><br>
              日期：2020-04-21 ~ 2020-07-12<br>
              <br>
              <b>地點</b><br>
              台南市中西區中華西路二段34號</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-sm-6 portfolio-item">
        <div class="card h-100">
          <a href="info_10.html">
            <img class="card-img-top" src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/397/f6zwn0zr5fh3sf3yn1ph7xvj7nua2ryh_1400x800.jpg" alt="">
          </a>
          <div class="card-body">
            <h4 class="card-title">
              <a href="info_10.html">測繪十年</a>
            </h4>
            <p class="card-text">
              <b>展期</b><br>
              日期：2020-06-13 ~ 2020-08-29<br>
              <br>
              <b>地點</b><br>
              台北市羅斯福路三段241號7樓</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-sm-6 portfolio-item">
        <div class="card h-100">
          <a href="info_11.html" target="_blanket">
            <img class="card-img-top" src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/333/evzz93lelan3iqdtf7ro169uwm1dt3hc_1400x800.jpg" alt="">
          </a>
          <div class="card-body">
            <h4 class="card-title">
              <a href="info_11.html">解形的光影—梁育瑄個展</a>
            </h4>
            <p class="card-text">
              <b>展期</b><br>
              日期：2020-06-06 ~ 2020-07-12<br>
              <br>
              <b>地點</b><br>
              大觀藝術空間</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-sm-6 portfolio-item">
        <div class="card h-100">
          <a href="info_12.html">
            <img class="card-img-top" src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/267/b5gz073ke2mmseuqwru72hmmeybg311j_1400x800.jpg" alt="">
          </a>
          <div class="card-body">
            <h4 class="card-title">
              <a href="info_12.html">再見 阿卡迪亞</a>
            </h4>
            <p class="card-text"><b>展期</b><br>
              日期：2020-05-23 ~ 2020-06-07<br>
              <br>
              <b>地點</b><br>
              北市中山北路二段72巷6號</p>
          </div>
        </div>
      </div>
    </div>

    <!-- /.row -->


  </div>
  <!-- /.container -->
  <ul class="pagination justify-content-center">
    <li class="page-item">
      <a class="page-link" href="index.php"  aria-label="Previous ">
          <span aria-hidden="true ">&laquo;</span>
          <span class="sr-only ">Previous</span>
        </a>
      </li>
      <li class="page-item ">
        <a class="page-link " style="background:#dee2e6;" href="index.php ">1</a>
      </li>
      <li class="page-item ">
        <a class="page-link "  href="index02.html">2</a>
      </li>
      <li class="page-item ">
        <a class="page-link " href="index02.html" aria-label="Next ">
          <span aria-hidden="true ">&raquo;</span>
          <span class="sr-only ">Next</span>
        </a>
      </li>
    </ul>

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; SA project</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>