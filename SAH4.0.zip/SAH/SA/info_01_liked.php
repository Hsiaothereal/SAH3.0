<?php 
      session_start();
      $userID=$_SESSION["userID"];//獲取是哪位使用者
      $acID=$_GET['activityid'];//接收空心頁面js傳來的值
      $acName=$_GET['activityname'];

      $hostname = "localhost";
      $username = "root";
      $password = "hsiao1999";
      $db_name="exhibitionx";

      try{
          $db=new PDO("mysql:host=".$hostname.";
                      dbname=".$db_name, $username, $password,
                      array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
                      //PDO::MYSQL_ATTR_INIT_COMMAND 設定編碼
                    
          //echo '連線成功';
          $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION); //錯誤訊息提醒
          
          
          $sql="INSERT INTO collect VALUES ('$acID', '$userID', '$acName')";
          //exec()針對沒有返回結果的操作，例如insert、update、delete等等
          $result=$db->exec($sql);
          }catch(PDOException $e) {
            echo $sql . "<br>" . $e->getMessage();
          }
    
?>


<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>阿麗莎·柯維德首度台灣個展</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/modern-business.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <!--Star-->
  <script src="js/star.js"></script>

  <style>
    * {
           margin: 0;
           padding: 0;
       }

       #pingfen {
           width: 135px;
           margin: 40px auto;
           height: 28px;
       }

       #pingfen li {
           width: 27px;
           float: left;
           height: 28px;
           cursor: pointer;
           background: url("star.png") no-repeat 0 0;
           list-style: none;
       }
      
       /*star*/
    .mystar {
            width: 300px;
            margin: 10px auto;
            font: 20px/1.5 arial;
            height: 100px;
            text-align: center;
        }
        #star {
            overflow: hidden;
            height: 35px;
            display: inline-block;
            margin: unset;
        }

        #star li {
            float: left;
            width: 20px;
            height: 20px;
            margin: 2px;
            display: inline;
            color: #999;
            font: bold 18px arial;
            cursor: pointer;
            font-size: 30px;
        }

        #star .act {
            color: #ffc107;
        }

        #star_word {
            width: 80px;
            height: 30px;
            line-height: 30px;
            border: 1px solid #ccc;
            margin: 0 auto;
            text-align: center;
            display: none
        }
       </style>
</head>

<body>

  <!-- Navigation -->
  <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="index.php">展給你看</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
        data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false"
        aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false">
              地區展覽
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
              <a class="dropdown-item" href="North-col.html">北區</a>
              <a class="dropdown-item" href="middle-col.html">中區</a>
              <a class="dropdown-item" href="south-col.html">南區</a>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog" data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false">
              會員資訊
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
              <a class="dropdown-item" href="full-width.html">收藏的展覽</a>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="login_page.html">登入</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!--Info頁面-->
  <div class="InfoClass">
    <div class="InfoTitle">
      <div>
        <h1>阿麗莎·柯維德首度台灣個展</h1>
      </div>
    </div>
    <div class="InfoImg">
      <img u="image"
        src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/079/452/4xo2hd71lzh59vqbboggjbu8f60wlbdn_1400x800.jpg"
        alt="" border="0">
    </div>
    <div class="InfoDate">
      <ul>
        <li>
          <h5>展期</h5>
          <p>日期：2020-04-28 ~ 2020-07-19</p>
        </li>
        <li>
          <h5>地點</h5>
          <p>內湖區寶湖里13鄰民權東路六段180巷10弄6號1樓</p>
        </li>
      </ul>
      <hr>
    </div>

    <div class="InfoContent">
      <div>
        <h2>內容</h2>
      </div>
      <p>文心藝術基金會繼上檔展覽 Danh Vo 的歷史敘事，本次文心藝所的展覽轉而探討現實的可能性。邀請觀眾走進阿麗莎·柯維德 Alicja Kwade的魔幻世界，重新質疑現存的觀念及想像多元的可能性。<br><br>
        「為了尋求真相，我們有必要在生活中盡可能地懷疑所有事物」──法國哲學家笛卡兒<br><br>
        幾千年來，人們一直試圖通過已知的方法及概念來度量、有限的詮釋現實(reality)。柯維德重新研究並質疑現實社會的結構，反思我們日常生活中對時空的感知。通過創造如同幻覺般的雕塑、裝置或影像，以數學、科學、哲學的方式重新闡述我們對時間、空間以及物質的概念。她的作品經常包括反射和重複的量體及聲音，使用這些元素來創造沉浸式和體驗式的空間，並鼓勵觀眾質疑他們對真實的信念。
      </p>
    </div>
  </div>
  <div class="mystar">
    對這展覽的興趣指數
    <span id="result">
      <ul id="star">
        <li>★</li>
        <li>★</li>
        <li>★</li>
        <li>★</li>
        <li>★</li>
      </ul>
      <div id="star_word">一般</div>
        </div>
  
  
      <script>
      function deliver(){
            location.href="info_01_like.php";
        }
      
      </script>
  
  <div class="plus">
    <button  onclick="deliver()">
     <img src="img/liked.png" style="width: 30px;">
    </button>
  </div>

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; SA project</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="js/scroll.js"></script>
</body>

</html>