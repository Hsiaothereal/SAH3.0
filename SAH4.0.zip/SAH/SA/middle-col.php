<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>中區展覽</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/modern-business.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Roboto', 'Noto Sans TC', 'Microsoft JhengHei', 'PMingLiU', 'Lato', sans-serif;
    }

    .img-fluid {
      width: 100%;
      max-height: 330px;
      max-width: 700px;
      height: 100%;
    }
  </style>
</head>

<body>

  <!-- Navigation -->
  <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="index.php">展給你看</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              地區展覽
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
              <a class="dropdown-item" href="North-col.php">北區</a>
              <a class="dropdown-item" href="middle-col.php">中區</a>
              <a class="dropdown-item" href="south-col.php">南區</a>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              會員資訊
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
              <a class="dropdown-item" href="full-width.php">收藏的展覽</a>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Logout.php">登出</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- Page Content -->
  <div class="container">

    <!-- Page Heading/Breadcrumbs -->
    <h1 class="mt-4 mb-3">中區展覽</h1>

    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="index.html">首頁</a>
      </li>
      <li class="breadcrumb-item active">中區展覽</li>
    </ol>

    <!-- Project One -->
    <div class="row">
      <div class="col-md-7">
        <a href="info_07.html">
          <img class="img-fluid rounded mb-3 mb-md-0"
            src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/414/b7fnlnxrhw66dupp47b0oezilm6z8jm3_1400x800.jpg" alt="">
        </a>
      </div>
      <div class="col-md-5">
         <h3>凹凸世界 版畫聯展</h3>
        <p>擅長以日本傳統的水性木凸版多色印刷的技法創作木版畫作，看似簡單的作品實則包含很深執著的意念在裡頭，透過色料、水以及力度的增減去尋找那最恰如其分的狀態。</p>
        <a class="btn btn-primary" href="info_07.html">閱讀更多
          <span class="glyphicon glyphicon-chevron-right"></span>
        </a>
      </div>
    </div>
    <!-- /.row -->

    <hr>

    <!-- Project Two -->
    <div class="row">
      <div class="col-md-7">
        <a href="info_14.html">
          <img class="img-fluid rounded mb-3 mb-md-0"
            src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/077/648/c84lj7g4yhgodivb90bup78w56z20qkb_1400x800.jpg"
            alt="">
        </a>
      </div>
      <div class="col-md-5">
        <h3>花園裡，植物記憶纏繞</h3>
        <p>「花園裡，植物記憶纏繞」是一個藝術與科學相會的展覽，也是珍奈特‧勞倫絲的創作在臺灣的首度呈現。勞倫絲以多樣的創作手法，不斷探索自然界物種之間的相互關係。其作品包括繪畫、裝置、錄像，但更多時候運用自然的元素­－動植物標本、活體植物、枯樹、種子、礦石、土壤－，也經常運用科學研究的用具材料。</p>
        <a class="btn btn-primary" href="info_14.html">閱讀更多
          <span class="glyphicon glyphicon-chevron-right"></span>
        </a>
      </div>
    </div>
    <!-- /.row -->

    <hr>

    <!-- Project Three -->
    <div class="row">
      <div class="col-md-7">
        <a href="info_23.html">
          <img class="img-fluid rounded mb-3 mb-md-0"
            src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/280/sxfzz9z2z8srjhupyx7mr1pmahcodf6f_1400x800.jpg"
            alt="">
        </a>
      </div>
      <div class="col-md-5">
        <h3>尋找光明－王曉勃個展 × 蔡尉成大型雕塑特展</h3>
        <p>
        「尋找光明」是一個直接而簡單的詞彙，但卻內蘊著找尋永恆真理的堅毅與勇氣，在成長道路上，真理的光明將是引領我們一步步通往夢想的方向。人生的道路崎嶇難行，但唯有經歷過混沌黑暗的過程，才會懂得珍惜光明的可貴，而那盞光明，也往往是身旁那被自己忽視已久的珍寶…
        </p>
        <a class="btn btn-primary" href="info_23.html">閱讀更多
          <span class="glyphicon glyphicon-chevron-right"></span>
        </a>
      </div>
    </div>
    <!-- /.row -->

    <hr>

    
    <!-- Pagination -->
   

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; SA project</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>