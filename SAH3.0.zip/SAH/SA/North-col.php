<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>北區展覽</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/modern-business.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Roboto', 'Noto Sans TC', 'Microsoft JhengHei', 'PMingLiU', 'Lato', sans-serif;
    }

    .img-fluid {
      width: 100%;
      max-height: 330px;
      max-width: 700px;
      height: 100%;
    }
  </style>
</head>

<body>

  <!-- Navigation -->
  <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="index.php">展給你看</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              地區展覽
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
              <a class="dropdown-item" href="North-col.php">北區</a>
              <a class="dropdown-item" href="middle-col.php">中區</a>
              <a class="dropdown-item" href="south-col.php">南區</a>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              會員資訊
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
              <a class="dropdown-item" href="full-width.php">收藏的展覽</a>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Logout.php">登出</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- Page Content -->
  <div class="container">

    <!-- Page Heading/Breadcrumbs -->
    <h1 class="mt-4 mb-3">北區展覽</h1>

    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="index.html">首頁</a>
      </li>
      <li class="breadcrumb-item active">北區展覽</li>
    </ol>

    <!-- Project One -->
    <div class="row">
      <div class="col-md-7">
        <a href="info_04.html">
          <img class="img-fluid rounded mb-3 mb-md-0"
            src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/079/360/wkm7pkaw55oi89k1ldq6020522zxfhgh_1400x800.jpg" alt="">
        </a>
      </div>
      <div class="col-md-5">
         <h3>深邃之城</h3>
        <p>「海洋與詮釋者」是從2020年起，一系列沿著「南方國家」而發展的計畫，結合了展覽、駐村研究、放映以及書寫，企圖重新理解南方觀點下的全球圖景。《詮釋者》（The Interpreters）是奈及利亞作家索因卡（Wole Soyinka）的作品，內容描述不同職業背景的歸國留學生如何重新看待這座新興的國家。></p>
        <a class="btn btn-primary" href="info_04.html">閱讀更多
          <span class="glyphicon glyphicon-chevron-right"></span>
        </a>
      </div>
    </div>
    <!-- /.row -->

    <hr>

    <!-- Project Two -->
    <div class="row">
      <div class="col-md-7">
        <a href="info_01.html">
          <img class="img-fluid rounded mb-3 mb-md-0"
            src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/079/452/4xo2hd71lzh59vqbboggjbu8f60wlbdn_1400x800.jpg"
            alt="">
        </a>
      </div>
      <div class="col-md-5">
        <h3>阿麗莎·柯維德首度台灣個展</h3>
        <p>文心藝術基金會繼上檔展覽 Danh Vo 的歷史敘事，本次文心藝所的展覽轉而探討現實的可能性。邀請觀眾走進阿麗莎·柯維德 Alicja
          Kwade的魔幻世界，重新質疑現存的觀念及想像多元的可能性。為了尋求真相，我們有必要在生活中盡可能地懷疑所有事物」──法國哲學家笛卡兒
          　　
          幾千年來，人們一直試圖通過已知的方法及概念來度量、有限的詮釋現實(reality)。柯維德重新研究並質疑現實社會的結構，反思我們日常生活中對時空的感知。通過創造如同幻覺般的雕塑、裝置或影像，以數學、科學、哲學的方式重新闡述我們對時間、空間以及物質的概念。...
        </p>
        <a class="btn btn-primary" href="info_01.html">閱讀更多
          <span class="glyphicon glyphicon-chevron-right"></span>
        </a>
      </div>
    </div>
    <!-- /.row -->

    <hr>

    <!-- Project Three -->
    <div class="row">
      <div class="col-md-7">
        <a href="info_05.html">
          <img class="img-fluid rounded mb-3 mb-md-0"
            src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/079/478/6uul39pv2y60ccyt44hpayhti9kzzh1n_1400x800.jpg"
            alt="">
        </a>
      </div>
      <div class="col-md-5">
        <h3>林忠良創作展</h3>
        <p>對於繪畫創作，個人最關心的部分不是技巧或風格，而是潛意識中那些連結個人情感與記憶的元素 –
          一種情緒的延伸。不善於刻意造作矯飾或追逐时代脈動，只想訓練自己能主觀表達出自我的藝術內涵，真誠傳達對自然人文的情感，以及對生命的尊重態度。
          生活中不是缺少美，而是缺少發現----羅丹...</p>
        <a class="btn btn-primary" href="info_05.html">閱讀更多
          <span class="glyphicon glyphicon-chevron-right"></span>
        </a>
      </div>
    </div>
    <!-- /.row -->

    <hr>

    <!-- Project Four -->
    <div class="row">

      <div class="col-md-7">
        <a href="info_03.html">
          <img class="img-fluid rounded mb-3 mb-md-0"
            src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/079/507/qj25pcpmmotomhrp1h25xqghl1cnjt4i_1400x800.jpg"
            alt="">
        </a>
      </div>
      <div class="col-md-5">
        <h3>X計畫—交換日記</h3>
        <p>
          【X計畫—交換日記】3人聯展，由李京樺、黃靖絜和李柏廷3位來自國立臺灣藝術大學美術學系的藝術新秀共同策劃，共計展出25件以壓克力、油彩及鉛筆等媒材創作之作品，他們對於當代藝術環境所帶給藝術創作者無形的禁錮有所感觸，認為自2000年後，臺灣當代視覺藝術創作者經常「自溺」於與自身相關、「個人」或「微觀」的創作議題中，和過去較常關注於「歷史記憶」及「批判社會體制」等議題大異其趣。...
        </p>
        <a class="btn btn-primary" href="info_03.html">閱讀更多
          <span class="glyphicon glyphicon-chevron-right"></span>
        </a>
      </div>
    </div>
    <!-- /.row -->

    <hr>
    <div class="row">

<div class="col-md-7">
  <a href="info_06.html">
    <img class="img-fluid rounded mb-3 mb-md-0"
      src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/448/8e3qn6mb334hbnfvwi20o9k3a798ewnm_1400x800.jpg" alt="">
  </a>
</div>
<div class="col-md-5">
  <h3>The Antinferno 安蒂菲諾</h3>
  <p>
  也趣藝廊去年九月正式駐點德國萊比錫斯賓佩納藝術園區（Spinnerei Leipzig），除全力傾注資源將不同世代的台灣藝術家帶往國際平台外，更持續引進優秀歐洲藝術家來台。2020年之初，德國藝術風暴再次席捲而來！出身德國第二古城奧格斯堡（Augsburg）的藝術家馬丁．伊德（Martin Eder）台灣首展－《The Antinferno安蒂菲諾》，將為亞洲觀眾獻上超寫實、超魔幻，精采程度更甚《冰與火之歌：權力遊戲》的史詩級鉅作。</p>
  <a class="btn btn-primary" href="info_06.html">閱讀更多
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
</div>
<!-- /.row -->

<hr>

    <div class="row">

<div class="col-md-7">
  <a href="info_10.html">
    <img class="img-fluid rounded mb-3 mb-md-0"
      src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/397/f6zwn0zr5fh3sf3yn1ph7xvj7nua2ryh_1400x800.jpg" alt="">
  </a>
</div>
<div class="col-md-5">
  <h3>測繪十年</h3>
  <p>
  在一般的認知中，「十」總被認為是「完滿」的象徵，因為它帶有「周而復始」、「回歸與再啟程」的意義。「十年」作為一個階段的達成，這個數字的視覺意象如同一條銜尾蛇般頭接尾，又像是在開展之中不斷循環、持續變化的碎形世界。同時，它也像使我們站在「跨越」的邊界上同時回顧過去和望向未來。正因這些意涵，立方計劃空間所走過的「十年」不只是一個數字，它還是一個測量與描繪的線索，引導我們去重新思索二十一世紀的台灣文化空間生產經驗和可能的未來期許。
</p>
  <a class="btn btn-primary" href="info_10.html">閱讀更多
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
</div>
<!-- /.row -->

<hr>

    <div class="row">

<div class="col-md-7">
  <a href="info_11.html">
    <img class="img-fluid rounded mb-3 mb-md-0"
      src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/333/evzz93lelan3iqdtf7ro169uwm1dt3hc_1400x800.jpg" alt="">
  </a>
</div>
<div class="col-md-5">
  <h3>解形的光影—梁育瑄個展</h3>
  <p>
  梁育瑄是次「解形的光影」個展，名稱來自於法國攝影師布列松所述名言「黑白攝影是解形的」。意旨在彩色視界轉化成黑白攝影時，即被進行選擇、調節與抽象化。其不僅重構擬真的繪畫空間，作品中也帶有解形的相反屬性，同時並抽離色彩，從而將空間敘事性以更為隱晦的方式呈現，讓觀者意欲探索其繪畫世界。</p>
  <a class="btn btn-primary" href="info_11.html">閱讀更多
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
</div>
<!-- /.row -->

<hr>

    <div class="row">

<div class="col-md-7">
  <a href="info_12.html">
    <img class="img-fluid rounded mb-3 mb-md-0"
      src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/267/b5gz073ke2mmseuqwru72hmmeybg311j_1400x800.jpg" alt="">
  </a>
</div>
<div class="col-md-5">
  <h3>再見 阿卡迪亞</h3>
  <p>
  阿卡迪亞，阿卡迪亞相傳是世界的中心，希臘文化中的烏托邦。作為世外桃源，傳說當人與人不再互相壓迫，不再爭名奪利，不再互相剝削，世間充滿博愛，阿卡迪亞便會再現。阿卡迪亞，原文意思為乘著方舟遠離死亡，然而在普桑的阿卡迪亞牧人（The Shepherds of Arcadia）死神在墓碑上說著他也在阿卡迪亞，意味著世間確實是紛亂仍在，永恆的烏托邦並不永恆。
</p>
  <a class="btn btn-primary" href="info_12.html">閱讀更多
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
</div>
<!-- /.row -->

<hr>

    <div class="row">

<div class="col-md-7">
  <a href="info_13.html">
    <img class="img-fluid rounded mb-3 mb-md-0"
      src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/079/591/hnwotvfhqm6kuysos743whmjjebp910u_1400x800.jpg" alt="">
  </a>
</div>
<div class="col-md-5">
  <h3>穿孔城市</h3>
  <p>
  最初確實從步登公寓聚落開始，但很快就將光譜加大，從一、二層老街聚落，到四、五樓現代步登公寓，到更高的當代大樓公寓聚落。聚落內的道路也從小巷弄、防火巷，到兩線道或更寬的車路。高度越低則距離越近，穿透性、交流性也越高，四、五層，特別是上面也有騎樓的步登公寓是一個臨界線，還能維持上述的關係。再往高發展配備電梯的大樓公寓聚落，則穿透性、交流性都驟減。當然，在聚落內部有更寬道路以及更快車輛穿越時，上述關係也會受到影響。
</p>
  <a class="btn btn-primary" href="info_13.html">閱讀更多
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
</div>
<!-- /.row -->

<hr>

    <div class="row">

<div class="col-md-7">
  <a href="info_15.html">
    <img class="img-fluid rounded mb-3 mb-md-0"
      src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/437/gextppw1vr6922mhsg0dbzvwuthhhept_1400x800.jpg" alt="">
  </a>
</div>
<div class="col-md-5">
  <h3>放風-寂靜之旅</h3>
  <p>
  新冠肺炎改變了全球人類的生活，對未來的人類處境開啟更多不同層面的思考。當看著歐美各國紛紛封城，各處空無一人的景象，身在台灣的我們，除了覺得防疫到位，很幸福的維持生活，你是否也感受到此波疫情帶給全球的寂靜體驗? 郭木生文教基金會特別策劃了「放風-寂靜之旅」</p>
  <a class="btn btn-primary" href="info_15.html">閱讀更多
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
</div>
<!-- /.row -->

<hr>

    <div class="row">

<div class="col-md-7">
  <a href="info_16.html">
    <img class="img-fluid rounded mb-3 mb-md-0"
      src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/390/qew7uk5srx3d2lu9tv87l9n63wdplxqt_1400x800.jpg" alt="">
  </a>
</div>
<div class="col-md-5">
  <h3>自由憧憬聯展 Back To The Life</h3>
  <p>
  人生的長河，徘迴在現實之間的棘手課題，驅使我們向現實妥協，如果暫且脫離現實回到生活的本質，總會有意想不到的閱歷與體驗等待著我們。在全球疫情的停滯狀態下，彷彿給人類上了一堂豐厚的生命教育，似乎得讓自己放慢腳步。回首過去的生活感知，從一道念想讓平白無奇的畫布有了重生的一面，也或許在過去的理想中感受到藝術不同的表述語彙。
</p>
  <a class="btn btn-primary" href="info_16.html">閱讀更多
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
</div>
<!-- /.row -->

<hr>

    <div class="row">

<div class="col-md-7">
  <a href="info_17.html">
    <img class="img-fluid rounded mb-3 mb-md-0"
      src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/360/stoqnh2i1pctisk96aqfpgh0v0q36cyf_1400x800.jpg" alt="">
  </a>
</div>
<div class="col-md-5">
  <h3>框與影</h3>
  <p>
  雅逸藝術中心將於2020年6月6日至7月26日推出「框與影－張驊個展」，展出藝術家張驊的最新系列創作，延續以往關注的「影像」和「感知」議題。張驊的創作主題聚焦探討事物的客觀存在和個體的主觀經驗，經由認知系統的整合、重塑及變形之後，進一步對事物做出理解和判斷。</p>
  <a class="btn btn-primary" href="info_17.html">閱讀更多
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
</div>
<!-- /.row -->

<hr>
<div class="row">

<div class="col-md-7">
  <a href="info_18.html">
    <img class="img-fluid rounded mb-3 mb-md-0"
      src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/382/xdt42mb3oqe5cfwu6av6hcdrhbei1t3p_1400x800.jpg" alt="">
  </a>
</div>
<div class="col-md-5">
  <h3>第二屆銅鐘藝術賞 x 同化者</h3>
  <p>
  空總臺灣當代文化實驗場（C-LAB）首次與洪建全基金會合作，將於6月6日假C-LAB通信分隊展演空間展出「第二屆 銅鐘藝術賞 ｛同化者｝鄭先喻個展」， 集結2010年代以來藝術家對網路、科技應用及感知模擬等時代技術的觀察反思，並利用非典型白盒子展場內規則分佈的樑柱與老舊建物病徵，再製／升級五組件之裝置創作展出。
</p>
  <a class="btn btn-primary" href="info_18.html">閱讀更多
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
</div>
<!-- /.row -->

<hr>
<div class="row">

<div class="col-md-7">
  <a href="info_19.html">
    <img class="img-fluid rounded mb-3 mb-md-0"
      src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/326/q66wdpxu7vznec9ciwdkyboxigjmqujp_1400x800.jpg" alt="">
  </a>
</div>
<div class="col-md-5">
  <h3>抹山河Ⅱ-黃琬玲個展</h3>
  <p>
  《名所繪》系列開始於2016年底，我以環景構圖、透視點切入思考架上繪畫問題，描繪一個非人眼透視結構的畫面。同時加入多種紙材拼貼與堆疊，材質間又是不同的空間想像。《名所繪》的透視點是放射線狀，從中心點開始，向外擴散的構圖方式、形成了沒有消失點的風景繪畫，藉此手法呼應文人繪畫的多點透視，並提出我對於風景繪畫的思考。</p>
  <a class="btn btn-primary" href="info_19.html">閱讀更多
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
</div>
<!-- /.row -->

<hr>
<div class="row">

<div class="col-md-7">
  <a href="info_20.html">
    <img class="img-fluid rounded mb-3 mb-md-0"
      src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/335/ulz5xkr6wy1bmhuth33s433mdf20arr7_1400x800.jpg" alt="">
  </a>
</div>
<div class="col-md-5">
  <h3>「再現．靈光」</h3>
  <p>
  在當代藝術思潮的討論之中，具象的繪畫作品是否能夠作為當代藝術的一環一向是深埋於藝術界深處的隱性疑問。自十九世紀末期，班雅明（Walter Benjamin，1892-1940）的「靈光（Aura）」的消失、丹托（Arthur C. Danto，1924-2013）的藝術終結，似乎為當代藝術的樣貌定下了樣貌，揭示了現代主義之後，藝術形式的態勢，迎來了多元的價值，罷黜了作者中心論。</p>
  <a class="btn btn-primary" href="info_20.html">閱讀更多
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
</div>
<!-- /.row -->

<hr>
<div class="row">

<div class="col-md-7">
  <a href="info_21.html">
    <img class="img-fluid rounded mb-3 mb-md-0"
      src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/398/rbxb5epadqukyrkbw5e14gl7svimx921_1400x800.jpg" alt="">
  </a>
</div>
<div class="col-md-5">
  <h3>精靈的夏日序曲 - 彼得·奧普海姆個展</h3>
  <p>
  我們不用企圖去找尋熟悉的具像，因為一堆球體可能意謂著個性及生活背景。
彼得．奧普海姆（Peter Opheim b.1961-），紐約藝術家，出生於德國。畫了20多年的抽象畫，後來逐漸轉變成今天我們所看到的風格。
</p>
  <a class="btn btn-primary" href="info_21.html">閱讀更多
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
</div>
<!-- /.row -->

<hr>
<div class="row">

<div class="col-md-7">
  <a href="info_22.html">
    <img class="img-fluid rounded mb-3 mb-md-0"
      src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/295/wjuhyi5n7nn9ub1jjrvpnpki93cz1x2v_1400x800.jpg" alt="">
  </a>
</div>
<div class="col-md-5">
  <h3>珠寶變奏曲‧美好年代的金工裝置</h3>
  <p>
  本次展覽著重東西洋珠寶的對觀，選擇東洋帯留/Obidome，搭配西洋浮雕/Cameo，演繹出變奏曲的優美對位，企圖回歸「十九世紀的古董訂製珠寶」，體現美好年代/Belle Époque的生活，並且說明「工藝開啟美術；美術昇華工藝」的浪漫精緻。
</p>
  <a class="btn btn-primary" href="info_22.html">閱讀更多
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
</div>
<!-- /.row -->

<hr>
<div class="row">

<div class="col-md-7">
  <a href="info_24.html">
    <img class="img-fluid rounded mb-3 mb-md-0"
      src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/080/266/8trxs26tww9362jvlcxz00kiqtze8b0y_1400x800.jpg" alt="">
  </a>
</div>
<div class="col-md-5">
  <h3>輪廓日常</h3>
  <p>
  繪畫計劃「輪廓日常」集結創作者從2019年冬天到2020年春天的生活觀察軌跡，六個月描繪了近四十張物件作品，從杯盤、刷具、石頭、日用品到食材，將物件置放於畫面中央，建構出與物件相互凝視的視線，與那些看似平凡的生活物件，創造了彼此所思所感的凝結時空。
  </p>
  <a class="btn btn-primary" href="info_24.html">閱讀更多
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
</div>
<!-- /.row -->

<hr>
    <!-- Pagination -->
   

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; SA project</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>