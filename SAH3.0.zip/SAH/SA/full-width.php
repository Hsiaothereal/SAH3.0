



<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Modern Business - Start Bootstrap Template</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/modern-business.css" rel="stylesheet">

<style>
    
  .favorite {
    height: 80vh;
    vertical-align: middle;
    display: table-cell;
    width: 1200px;
  } 
  button {
    border: unset;
    color: #EEE;
    background-color: #333;
}
</style>

</head>

<body>

   <!-- Navigation -->
   <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="index.php">展給你看</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
        data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false"
        aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false">
              地區展覽
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
              <a class="dropdown-item" href="North-col.php">北區</a>
              <a class="dropdown-item" href="middle-col.php">中區</a>
              <a class="dropdown-item" href="south-col.php">南區</a>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog" data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false">
              會員資訊
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
              <a class="dropdown-item" href="full-width.php">收藏的展覽</a>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="login_page.html">登出</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
<div class='container'>
  <div class='favorite'>
    <table class="table table-hover">
      <thead>
        <tr>
          <th scope="col">展覽名稱</th>
          <th scope="col">地區</th>
          <th scope="col">時間</th>
          <th scope="col">收藏</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th scope="row"><div><a href="info.php">阿麗莎·柯維德首度台灣個展</a></div></th>
          <td>北區</td>
          <td>4/28~7/19</td>
          <td><button onclick="editTable.delRow()">取消</button></td>
        </tr>
        <tr>
          <th scope="row"><div><a href="#">珍奈特．勞倫絲個展</a></div></th>
          <td>北區</td>
          <td>5/05~7/17</td>
          <td><button>取消</button></td>
        </tr>
        <tr>
          <th scope="row"><div><a href="#">林忠良創作展</a></div></th>
          <td>中區</td>
          <td>4/19~6/24</td>
          <td><button>取消</button></td>
        </tr>
      </tbody>
    </table>

  </div>

</div>
    <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Your Website 2019</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

<script>
  delRow:function(){
if($("tr").length <= 2){
return;
}
$("tr:last").remove();
}
</script>

</html>
