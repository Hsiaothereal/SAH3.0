
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>會員註冊</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/modern-business.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <style>
    body {
      font-family: "Noto Sans TC", "Roboto";
    }

    .Login {
      /* The image used */
      background-image: url("img/login_page.jpg");


      /* Full height */
      height: 100%;

      /* Center and scale the image nicely */
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
    }

    /* style the container */

    .Login {
      position: relative;
      background-color: #f2f2f2;
      padding: 20px 0 30px 0;
      color: #fff;
    }

    /* style inputs and link buttons */

    input,
    .btn {
      width: 100%;
      padding: 12px;
      border: none;
      border-radius: 4px;
      margin: 5px 0;
      opacity: 0.85;
      display: inline-block;
      font-size: 17px;
      line-height: 20px;
      text-decoration: none;
      /* remove underline from anchors */
    }

    input:hover,
    .btn:hover {
      opacity: 1;
    }

    /* add appropriate colors to fb, twitter and google buttons */

    .fb {
      background-color: #3B5998;
      color: white;
    }

    .twitter {
      background-color: #55ACEE;
      color: white;
    }

    .google {
      background-color: #dd4b39;
      color: white;
    }

    /* style the submit button */

    input[type=submit] {
      background-color: #4CAF50;
      color: white;
      cursor: pointer;
    }

    input[type=submit]:hover {
      background-color: #45a049;
    }

    /* Two-column layout */

    .col {
      width: 100%;
      max-width: 500px;
      margin: auto;
      padding: 0 50px;
      margin-top: 0px;
    }

    /* Clear floats after the columns */

    .rower:after {
      content: "";
      display: table;
      clear: both;
    }

    /* vertical line */

    .vl {
      display: none;
      position: absolute;
      left: 50%;
      transform: translate(-50%);
      border: 2px solid #ddd;
      height: 175px;
    }

    /* text inside the vertical line */

    .vl-innertext {
      position: absolute;
      top: 50%;
      transform: translate(-50%, -50%);
      background-color: #f1f1f1;
      border: 1px solid #ccc;
      border-radius: 50%;
      padding: 8px 10px;
    }

    /* hide some text on medium and large screens */

    .hide-md-lg {
      display: block;
      text-align: center;
    }

    /* bottom container */

    .bottom-container {
      text-align: center;
      background-color: #666;
      border-radius: 0px 0px 4px 4px;
    }

   
  </style>

</head>

<body>
  <!-- Navigation -->
  <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="index.html">展給你看</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive"
        aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              地區展覽
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
              <a class="dropdown-item" href="North-col.html">北區</a>
              <a class="dropdown-item" href="middle-col.html">中區</a>
              <a class="dropdown-item" href="south-col.html">南區</a>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              會員資訊
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
              <a class="dropdown-item" href="full-width.html">收藏的展覽</a>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Login.php">登入</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!--container-->
  <div class="LoginBlock">
    <div class="Login">
      <form action="Login.php" method="post">
        <div class="rower">
          <h2 style="text-align:center">會員註冊 / Sign Up</h2>
          <div class="vl">
            <span class="vl-innertext">or</span>
          </div>

          <div class="col">
            <input type="text" name="username" placeholder="使用者ID" required>
            <input type="password" name="password" placeholder="密碼" required>
            <input type="number" name="age" placeholder="年齡" required>
            <input type="email" name="email" placeholder="信箱" required>
            <input type="submit" value="註冊">
          </div>

        </div>
      </form>

      <div class="col">
        <div class="bottom-container">
          <div class="rower ">
            <div class="col">
              <a href="Login.php" style="color:white" class="btn">會員登入</a>
            </div>
          </div>
        </div>
      </div>
    </div>


  </div>

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Your Website 2019</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>