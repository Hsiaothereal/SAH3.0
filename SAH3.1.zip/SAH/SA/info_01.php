<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>阿麗莎·柯維德首度台灣個展</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/modern-business.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <!--Star-->
  <script src="js/star.js"></script>

  <style>
    * {
           margin: 0;
           padding: 0;
       }

       #pingfen {
           width: 135px;
           margin: 40px auto;
           height: 28px;
       }

       #pingfen li {
           width: 27px;
           float: left;
           height: 28px;
           cursor: pointer;
           background: url("star.png") no-repeat 0 0;
           list-style: none;
       }
       </style>
</head>

<body>

  <!-- Navigation -->
  <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="index.php">展給你看</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
        data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false"
        aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false">
              地區展覽
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
              <a class="dropdown-item" href="North-col.html">北區</a>
              <a class="dropdown-item" href="middle-col.html">中區</a>
              <a class="dropdown-item" href="south-col.html">南區</a>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog" data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false">
              會員資訊
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
              <a class="dropdown-item" href="full-width.html">收藏的展覽</a>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="login_page.html">登入</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!--Info頁面-->
  <div class="InfoClass">
    <div class="InfoTitle">
      <div>
        <h1>阿麗莎·柯維德首度台灣個展</h1>
      </div>
    </div>
    <div class="InfoImg">
      <img u="image"
        src="https://d2onjhd726mt7c.cloudfront.net/images/datas/000/079/452/4xo2hd71lzh59vqbboggjbu8f60wlbdn_1400x800.jpg"
        alt="" border="0">
    </div>
    <div class="InfoDate">
      <ul>
        <li>
          <h5>展期</h5>
          <p>日期：2020-04-28 ~ 2020-07-19</p>
        </li>
        <li>
          <h5>地點</h5>
          <p>內湖區寶湖里13鄰民權東路六段180巷10弄6號1樓</p>
        </li>
      </ul>
      <hr>
    </div>

    <div class="InfoContent">
      <div>
        <h2>內容</h2>
      </div>
      <p>文心藝術基金會繼上檔展覽 Danh Vo 的歷史敘事，本次文心藝所的展覽轉而探討現實的可能性。邀請觀眾走進阿麗莎·柯維德 Alicja Kwade的魔幻世界，重新質疑現存的觀念及想像多元的可能性。<br><br>
        「為了尋求真相，我們有必要在生活中盡可能地懷疑所有事物」──法國哲學家笛卡兒<br><br>
        幾千年來，人們一直試圖通過已知的方法及概念來度量、有限的詮釋現實(reality)。柯維德重新研究並質疑現實社會的結構，反思我們日常生活中對時空的感知。通過創造如同幻覺般的雕塑、裝置或影像，以數學、科學、哲學的方式重新闡述我們對時間、空間以及物質的概念。她的作品經常包括反射和重複的量體及聲音，使用這些元素來創造沉浸式和體驗式的空間，並鼓勵觀眾質疑他們對真實的信念。
      </p>
      </li>
      </ul>
    </div>
  </div>
  <div class="star">
    <div id="pingfen">
      <p>這展覽的興趣指數</p>
      <ul>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
      </ul>
    </div>
  </div>
  <div class="plus">
    <button>
      <img src="img/like.png" style="width:60px;margin-right:5px;margin-left:3px;margin-top:8px;margin-bottom:4px">
    </button>
  </div>

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; SA project</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <script>
    function myFunction() {
      var x = document.getElementById("btnHeart");
      if (x.innerHTML == "<svg class='bi bi-heart' width='1em' height='1em' viewBox='0 0 16 16' fill='currentColor' xmlns='http://www.w3.org/2000/svg'><path fill-rule='evenodd'   d='M8 2.748l-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01L8 2.748zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143c.06.055.119.112.176.171a3.12 3.12 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15z' /></svg>") {
        x.innerHTML = "<svg class='bi bi-heart-fill' width='1em' height='1em' viewBox='0 0 16 16' fill='currentColor' xmlns='http://www.w3.org/2000/svg'><path fill-rule='evenodd' d='M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314z'/></svg>";
      } else {
        x.innerHTML = "<svg class='bi bi-heart-fill' width='1em' height='1em' viewBox='0 0 16 16' fill='currentColor' xmlns='http://www.w3.org/2000/svg'><path fill-rule='evenodd' d='M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314z'/></svg>";
      }
    }
    window.onload = function () {
        var oPf = document.getElementById('pingfen');
        var aLi = oPf.getElementsByTagName('li');
        var i = 0;
        for (i = 0; i < aLi.length; i++) {
            aLi[i].index = i;
            aLi[i].onmouseover = function () {
                for (i = 0; i < aLi.length; i++) {
                    if (i <= this.index) {
                        aLi[i].style.background = "url(img/star.png) no-repeat 0 -29px";
                    }
                    else {
                        aLi[i].style.background = "url(img/star.png) no-repeat 0 0";
                    }
                }
            };
    
            aLi[i].onmousedown = function () {
                alert('提交成功:' + (this.index + 1) + '分');
            };
        }
    };

  </script>

</body>

</html>